export default function Joke(props) {
    return (
        <>
            <p style={{display: props.setup  "none"}} className="setup">Setup: {props.setup}</p>
            <p className="punchline">Punchline: {props.punchline}</p>
            <hr />
        </>
    )
}