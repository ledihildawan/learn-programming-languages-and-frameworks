import React from "react"
import { createRoot } from "react-dom/client"

const LOGO_SRC = "react-logo.png"
const LOGO_WIDTH = 40

function Logo({ withText = false }) {
  return (
    <div className="logo">
      <img src={LOGO_SRC} width={LOGO_WIDTH} alt="React logo" />
      {withText && <span>ReactFacts</span>}
    </div>
  )
}

function FactItem({ text }) {
  return (
    <li>
      <span className="bullet" /> {/* Replace or style as needed */}
      <span>{text}</span>
    </li>
  )
}

function Header() {
  return (
    <header>
      <Logo withText />
    </header>
  )
}

function MainContent() {
  const facts = [
    "Was first released in 2013",
    "Was originally created by Jordan Walke",
    "Is maintained by Meta",
    "Powers thousands of enterprise apps, including mobile apps"
  ]

  return (
    <main>
      <h1>Fun facts about React</h1>
      <ul>
        {facts.map((fact, index) => (
          <FactItem key={index} text={fact} />
        ))}
      </ul>
      <img
        src={LOGO_SRC}
        width={LOGO_WIDTH}
        alt="React logo background"
        className="decoration-react-logo"
      />
    </main>
  )
}

function App() {
  return (
    <>
      <Header />
      <MainContent />
    </>
  )
}

const root = createRoot(document.getElementById("root"))
root.render(<App />)
